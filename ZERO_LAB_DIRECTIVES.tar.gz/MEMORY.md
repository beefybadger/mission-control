# MEMORY INDEX

## Active Context (Always Load)
- [Zero Lab AI](memory/projects/zero_lab_ai.md): Core mission and active experiments.
- [Robert Profile](memory/people/robert.md): Goals, preferences, and skill level.

## People
| Name | Role | Trigger Keywords | Detail File |
| :--- | :--- | :--- | :--- |
| Robert | Human / Student | robert, user, profile, developer | [robert.md](memory/people/robert.md) |
| Baron | AI / Teacher | baron, identity, role, expert | [FOUNDATION.md](FOUNDATION.md) |
| Scotty | AI / Scout | scotty, research, hunt, trends | [projects/zero_lab_ai.md](memory/projects/zero_lab_ai.md) |
| Maurice | AI / Creative Director | maurice, brainstorm, ideas, revenue | [projects/zero_lab_ai.md](memory/projects/zero_lab_ai.md) |


## Projects
| Project | Status | Trigger Keywords | Detail File |
| :--- | :--- | :--- | :--- |
| Zero Lab AI | Scrapped | skool, community, lab | [zero_lab_ai.md](memory/projects/zero_lab_ai.md) |
| Sentinel | Primary | sentinel, monitoring, reddit, intent | [projects/zero_lab_ai.md](memory/projects/zero_lab_ai.md) |
| Affiliate Bridge | Active | affiliate, ecommerce, gorgias, klaviyo, supabase, dashboard | [projects/zero_lab_ai.md](memory/projects/zero_lab_ai.md) |
| Command Center | Active | dashboard, hq, streamlit, tunnel | [projects/zero_lab_ai.md](memory/projects/zero_lab_ai.md) |

## Decisions & Lessons
- [Feb 2026 Log](memory/decisions/2026-02.md): Memory system, Role definition, Pain-point strategy, No-Human Company pivot.

## Drill-Down Rules
1. **People/Projects:** Mandatory drill-down if name/project is mentioned and not in Active Context.
2. **Context Shift:** If the user pivots to a new topic, check Index for relevant Detail Files.
3. **Index Cap:** Maintain under 3k tokens. Archive rows to `memory/archive/` if inactive > 30 days.
