# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Robert
- **What to call them:** Robert
- **Pronouns:** *(optional)*
- **Timezone:** Europe/Berlin (GMT+1)
- **Notes:** Wants to make enough money to leave a 9–5 job; working with the assistant as a partner (“Baron”).
- **Comms prefs:** OK with proactive Telegram messages for requested reminders + system alerts. Quiet hours 23:00–08:00 (Europe/Berlin), unless critical.

## Context

- Primary goal: build income streams so Robert can quit his 9–5.

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
